ROYAL WEDDING HUB — SOURCE ZIP

Included: index.html (existing design retained with added admin/cloud features), square app icon, PWA manifest, service worker.

CLOUDINARY
- Cloud name prefilled: a1tdz43b
- Upload preset was not present as a specific value in the supplied message, so enter your Cloudinary UNSIGNED upload preset in Admin after opening the app.
- Open the Admin section and unlock with initial PIN 123456, then save cloud name/preset. Change the PIN there.
- Cloud uploads work only when the preset is an unsigned upload preset enabled in Cloudinary settings.

IMPORTANT
- This is a web app source package, not a compiled Android APK. Host it on HTTPS (for example GitHub Pages) to use PWA install/service worker features.
- The front-end PIN is a convenience lock only; do not treat it as secure authentication. For production admin security, use a server/backend.
- Without an upload preset, gallery files stay in this browser/device as before.
